# ================= SUPPRESS WARNINGS FIRST =================
import warnings
warnings.filterwarnings("ignore", category=Warning)
warnings.filterwarnings("ignore", message=".*fractional coordinates.*")
warnings.filterwarnings("ignore", message=".*occupancies.*")
warnings.filterwarnings("ignore", message=".*No structure parsed.*")
warnings.filterwarnings("ignore", module="pymatgen.*")

# ================= IMPORTS =================
import os
import sqlite3
import math
import re
import time
import multiprocessing as mp
from queue import Empty, Full
from functools import lru_cache
import numpy as np
from collections import defaultdict

from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

# ================= CONFIGURATION =================
CIF_ROOT = r"D:\Project XRD XRF\COD SQL Database\cod-cifs-mysql\cif"
OUTPUT_DB = "cod_xrd_final.db"
MAX_PEAKS = 20

# Optimized for Ryzen 7
NUM_PROCESSES = 20
QUEUE_SIZE = 2000
BATCH_SIZE = 500
COMMIT_INTERVAL = 5000

# ================= MINERAL CLASSIFICATION DATA =================
MINERAL_GROUPS = {
    'sulfide': ['cinnabar', 'pyrite', 'chalcopyrite', 'galena', 'sphalerite', 'pyrrhotite', 'arsenopyrite', 'bornite', 'chalcocite', 'covellite', 'molybdenite', 'stibnite', 'realgar', 'orpiment', 'argentite', 'acanthite', 'pentlandite', 'millerite', 'cobaltite', 'sperrylite'],
    'sulfosalt': ['tetrahedrite', 'tennantite', 'enargite', 'bournonite', 'jamesonite', 'boulangerite', 'proustite', 'pyrargyrite', 'stephanite', 'polybasite'],
    'oxide': ['hematite', 'magnetite', 'ilmenite', 'rutile', 'anatase', 'brookite', 'corundum', 'cassiterite', 'chromite', 'spinel', 'goethite', 'limonite', 'bauxite', 'pyrolusite', 'psilomelane', 'columbite', 'tantalite', 'wolframite', 'scheelite', 'uraninite'],
    'hydroxide': ['brucite', 'gibbsite', 'diaspore', 'boehmite', 'manganite', 'romanechite', 'todorokite'],
    'halide': ['halite', 'fluorite', 'sylvite', 'carnallite', 'cryolite', 'atacamite', 'chlorargyrite', 'iodargyrite'],
    'carbonate': ['calcite', 'aragonite', 'dolomite', 'magnesite', 'siderite', 'rhodochrosite', 'smithsonite', 'cerussite', 'malachite', 'azurite', 'strontianite', 'witherite'],
    'sulfate': ['gypsum', 'anhydrite', 'barite', 'celestine', 'anglesite', 'alunite', 'jarosite', 'chalcanthite', 'melanterite', 'epsomite', 'mirabilite', 'thenardite', 'glauberite'],
    'phosphate': ['apatite', 'monazite', 'xenotime', 'vivianite', 'turquoise', 'variscite', 'strengite', 'childrenite', 'amblygonite', 'triphylite', 'lithiophilite', 'wavellite'],
    'nesosilicate': ['olivine', 'forsterite', 'fayalite', 'garnet', 'almandine', 'pyrope', 'spessartine', 'grossular', 'zircon', 'sphene', 'topaz', 'staurolite', 'sillimanite', 'andalusite', 'kyanite'],
    'pyroxene': ['enstatite', 'diopside', 'hedenbergite', 'augite', 'pigeonite', 'jadeite', 'aegirine', 'spodumene', 'wollastonite', 'rhodonite'],
    'amphibole': ['tremolite', 'actinolite', 'hornblende', 'anthophyllite', 'riebeckite', 'glaucophane', 'arfvedsonite', 'cummingtonite'],
    'phyllosilicate': ['muscovite', 'biotite', 'phlogopite', 'lepidolite', 'kaolinite', 'halloysite', 'dickite', 'serpentine', 'chrysotile', 'antigorite', 'lizardite', 'talc', 'pyrophyllite', 'chlorite', 'clinochlore', 'montmorillonite'],
    'silica': ['quartz', 'cristobalite', 'tridymite', 'coesite', 'stishovite', 'chalcedony', 'chert', 'flint', 'jasper', 'agate', 'opal'],
    'feldspar': ['orthoclase', 'microcline', 'sanidine', 'albite', 'oligoclase', 'andesine', 'labradorite', 'bytownite', 'anorthite', 'plagioclase', 'anorthoclase'],
    'zeolite': ['analcime', 'chabazite', 'clinoptilolite', 'heulandite', 'laumontite', 'mordenite', 'natrolite', 'phillipsite', 'stilbite', 'thomsonite'],
    'native_element': ['gold', 'silver', 'copper', 'platinum', 'iron', 'nickel', 'arsenic', 'antimony', 'bismuth', 'sulfur', 'diamond', 'graphite']
}

# Pre-compile regex patterns for speed
NAME_TO_GROUP_MAP = {}
for group, minerals in MINERAL_GROUPS.items():
    for name in minerals:
        NAME_TO_GROUP_MAP[name.lower()] = group.upper()

ANION_GROUPS = {
    'carbonate': [re.compile(r'CO3', re.IGNORECASE), re.compile(r'\(CO3\)', re.IGNORECASE)],
    'sulfate': [re.compile(r'SO4', re.IGNORECASE), re.compile(r'\(SO4\)', re.IGNORECASE)],
    'phosphate': [re.compile(r'PO4', re.IGNORECASE), re.compile(r'\(PO4\)', re.IGNORECASE)],
    'silicate': [re.compile(r'SiO4', re.IGNORECASE), re.compile(r'Si2O', re.IGNORECASE)]
}

# ================= NAME EXTRACTION =================
@lru_cache(maxsize=1000)
def normalize_name(name):
    """Cached name normalization"""
    if not name or name == '?' or name.lower() in ['unknown', 'na', 'n/a', 'none']:
        return None
    
    # Remove quotes and extra spaces
    name = re.sub(r'["\'`]', '', str(name))
    name = re.sub(r'\s+', ' ', name).strip()
    
    # Remove parenthetical content that's usually just annotations
    name = re.sub(r'\s*\([^)]*\)\s*', ' ', name).strip()
    
    # Skip if too short or looks like a code
    if len(name) < 2 or re.match(r'^[0-9]+$', name):
        return None
    
    return name

def extract_mineral_name_from_cif(cif_path):
    """Comprehensive mineral name extraction from CIF files"""
    try:
        with open(cif_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(5000)  # Read first 5000 chars
            
            # CIF tags that might contain mineral names
            name_tags = [
                '_chemical_name_mineral',
                '_chemical_name_common',
                '_chemical_name_systematic',
                '_chemical_name_structure_type',
                '_pd_phase_name',
                '_cod_database_related_name',
                '_chemical_name'
            ]
            
            lines = content.split('\n')
            for line in lines:
                line_lower = line.lower()
                
                for tag in name_tags:
                    if tag in line_lower:
                        parts = line.split(None, 1)
                        if len(parts) > 1:
                            name = parts[1].strip("'\";, ")
                            normalized = normalize_name(name)
                            if normalized:
                                return normalized
    except Exception:
        pass
    
    return None

def get_mineral_name_from_filename(cif_path):
    """Extract potential mineral name from filename"""
    filename = os.path.basename(cif_path).replace('.cif', '')
    
    # COD IDs are numeric - if it's just numbers, it's not a name
    if re.match(r'^\d+$', filename):
        return None
    
    # Clean up filename
    name = re.sub(r'[-_]\d+$', '', filename)
    name = re.sub(r'[_-]', ' ', name)
    
    return normalize_name(name)

# ================= OPTIMIZED HELPERS =================
def classify_mineral_group(formula, name_lower):
    """Optimized classification with early returns"""
    if name_lower in NAME_TO_GROUP_MAP: 
        return NAME_TO_GROUP_MAP[name_lower]
    
    if not formula: 
        return "UNKNOWN"
    
    f_upper = formula.upper()
    
    # Fast checks first
    if re.search(r'F$|Cl$|Br$|I$', f_upper): 
        return "HALIDE"
    
    # Check anion groups
    for group, patterns in ANION_GROUPS.items():
        for pattern in patterns:
            if pattern.search(f_upper):
                return group.upper() if group != 'silicate' else "SILICATE"
    
    # Simple composition checks
    if re.match(r'^[A-Z][a-z]?$', f_upper): 
        return "NATIVE ELEMENT"
    
    if 'S' in f_upper and 'O' not in f_upper: 
        return "SULFIDE"
    
    if 'O' in f_upper:
        if not any(x in f_upper for x in ['C', 'S', 'P', 'SI', 'N', 'B']): 
            return "OXIDE"
    
    return "OTHER"

def classify_category(formula, mineral_group):
    """Simplified category classification"""
    if not formula: 
        return "UNKNOWN"
    
    f_upper = formula.upper()
    
    # Quick mineral check
    valid_groups = {'OXIDE', 'SILICATE', 'SULFIDE', 'CARBONATE', 'SULFATE', 
                    'PHOSPHATE', 'HALIDE', 'NATIVE ELEMENT'}
    
    if mineral_group in valid_groups:
        return "MINERAL"
    
    # Organic check
    if 'C' in f_upper and 'H' in f_upper:
        if any(m in f_upper for m in ['NA', 'K', 'CA', 'MG', 'FE', 'AL']):
            return "METAL-ORGANIC"
        return "ORGANIC"
    
    return "INORGANIC"

# ================= OPTIMIZED WORKER =================
def worker_process(cif_paths, result_queue, worker_id):
    """Optimized worker with local imports and batch processing"""
    results = []
    success = 0
    fail = 0
    unnamed_count = 0
    
    # Local calculator instance for this worker
    calculator = XRDCalculator(wavelength="CuKa")
    
    for cif_path in cif_paths:
        try:
            structure = Structure.from_file(cif_path, primitive=False)
            
            # Quick filters
            n_sites = structure.num_sites
            if n_sites == 0 or n_sites > 500: 
                fail += 1
                continue
            
            formula = structure.composition.reduced_formula
            
            # Skip hydrogen-rich organics quickly
            if "H" in formula and n_sites < 20: 
                fail += 1
                continue

            # Crystal system
            try:
                analyzer = SpacegroupAnalyzer(structure, symprec=0.1)
                crystal_system = analyzer.get_crystal_system()
            except:
                crystal_system = "UNKNOWN"

            # XRD calculation
            pattern = calculator.get_pattern(structure, two_theta_range=(5, 90))
            if len(pattern.x) == 0: 
                fail += 1
                continue
            
            # Peak calculation
            two_theta = pattern.x
            intensities = pattern.y
            theta_rad = np.radians(two_theta / 2)
            d_spacings = 1.5406 / (2 * np.sin(theta_rad))
            
            # Create peaks and sort
            peaks = list(zip(np.round(d_spacings, 3), np.round(intensities, 2)))
            peaks.sort(key=lambda x: x[1], reverse=True)

            # Name extraction
            name = extract_mineral_name_from_cif(cif_path)
            
            if not name:
                name = get_mineral_name_from_filename(cif_path)
            
            if not name:
                name = f"Unnamed_{formula}"
                unnamed_count += 1
            
            # Get classifications
            mineral_group = classify_mineral_group(formula, name.lower())
            category = classify_category(formula, mineral_group)
            
            results.append({
                'cod_id': os.path.basename(cif_path).replace('.cif', ''),
                'name': name, 
                'formula': formula,
                'crystal_system': crystal_system,
                'mineral_group': mineral_group, 
                'category': category,
                'peaks': peaks[:MAX_PEAKS]
            })
            success += 1
            
        except Exception:
            fail += 1
        
        # Batch send results
        if len(results) >= BATCH_SIZE:
            _send_with_retry(result_queue, ('DATA', worker_id, results))
            results = []
    
    # Send remaining results
    if results:
        _send_with_retry(result_queue, ('DATA', worker_id, results))
    
    # Send completion stats
    _send_with_retry(result_queue, ('DONE', worker_id, {
        'success': success, 
        'fail': fail,
        'unnamed': unnamed_count
    }))

def _send_with_retry(queue, msg, max_retries=5):
    """Helper to retry sending to queue"""
    for _ in range(max_retries):
        try:
            queue.put(msg, block=False)
            return
        except Full:
            time.sleep(0.1)
    queue.put(msg, block=True)

# ================= OPTIMIZED WRITER =================
def db_writer_process(result_queue, total_files, db_path, num_workers):
    """Optimized database writer with detailed progress display"""
    # Database setup
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.execute("PRAGMA cache_size=-2000000")  # 2GB cache
    cursor.execute("PRAGMA temp_store=MEMORY")
    
    # Create table
    cols = ["cod_id TEXT PRIMARY KEY", 
            "substance_name TEXT", 
            "category TEXT", 
            "mineral_group TEXT", 
            "crystal_system TEXT", 
            "chemical_formula TEXT"]
    for i in range(1, MAX_PEAKS + 1):
        cols.extend([f"d{i} REAL", f"i{i} REAL"])
    cursor.execute(f"CREATE TABLE IF NOT EXISTS minerals ({', '.join(cols)})")
    
    # Create indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_name ON minerals(substance_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_group ON minerals(mineral_group)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_category ON minerals(category)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_formula ON minerals(chemical_formula)")
    conn.commit()
    
    # Statistics tracking
    processed = 0
    completed = 0
    start_time = time.time()
    last_display = start_time
    worker_stats = {i: {'success': 0, 'fail': 0, 'unnamed': 0} for i in range(num_workers)}
    records_since_commit = 0
    
    # Detailed metrics
    unique_minerals = set()
    unnamed_minerals = set()
    crystal_system_counts = defaultdict(int)
    formula_counts = defaultdict(int)
    total_d_spacings = 0
    d_spacing_sum = 0
    
    # Track success/fail from all sources
    total_success = 0
    total_fail = 0
    
    # For displaying sample formulas
    recent_formulas = []
    
    print(f"\n{'='*100}")
    print(f"🚀 DATABASE WRITER STARTED - Processing {total_files:,} files")
    print(f"{'='*100}\n")
    
    try:
        while completed < num_workers:
            try:
                msg = result_queue.get(timeout=1)
            except Empty:
                # Update display periodically
                current_time = time.time()
                if current_time - last_display >= 2:  # Update every 2 seconds
                    _display_detailed_progress(
                        processed, total_files, start_time, 
                        total_success, total_fail,
                        unique_minerals, unnamed_minerals, crystal_system_counts,
                        formula_counts, total_d_spacings, d_spacing_sum,
                        recent_formulas
                    )
                    last_display = current_time
                continue
            
            mtype, wid, payload = msg
            if mtype == 'DONE':
                completed += 1
                worker_stats[wid] = payload
                # Add to totals when worker completes
                total_success += payload['success']
                total_fail += payload['fail']
            elif mtype == 'DATA':
                # Process batch
                records = []
                for item in payload:
                    # Prepare record
                    record = [item['cod_id'], item['name'], item['category'], 
                             item['mineral_group'], item['crystal_system'], item['formula']]
                    for j in range(MAX_PEAKS):
                        if j < len(item['peaks']):
                            record.extend([item['peaks'][j][0], item['peaks'][j][1]])
                        else:
                            record.extend([None, None])
                    records.append(record)
                    
                    # Update statistics
                    processed += 1
                    unique_minerals.add(item['name'])
                    
                    if item['name'].startswith('Unnamed_'):
                        unnamed_minerals.add(item['name'])
                    
                    crystal_system_counts[item['crystal_system']] += 1
                    formula_counts[item['formula']] += 1
                    
                    # Track d-spacings
                    n_peaks = len(item['peaks'])
                    total_d_spacings += n_peaks
                    for d, _ in item['peaks']:
                        d_spacing_sum += d
                    
                    # Store recent formulas for display
                    if len(recent_formulas) < 5:
                        if item['formula'] not in recent_formulas:
                            recent_formulas.append(item['formula'])
                    else:
                        # Rotate
                        if item['formula'] not in recent_formulas:
                            recent_formulas.pop(0)
                            recent_formulas.append(item['formula'])
                
                # Batch insert
                cursor.executemany(
                    f"INSERT OR REPLACE INTO minerals VALUES ({', '.join(['?']*len(records[0]))})", 
                    records
                )
                records_since_commit += len(records)
                
                if records_since_commit >= COMMIT_INTERVAL:
                    conn.commit()
                    records_since_commit = 0
                    
    finally:
        conn.commit()
        conn.close()
        # Final detailed display
        _display_detailed_progress(
            processed, total_files, start_time,
            total_success, total_fail,
            unique_minerals, unnamed_minerals, crystal_system_counts,
            formula_counts, total_d_spacings, d_spacing_sum,
            recent_formulas, final=True
        )

def _display_detailed_progress(processed, total_files, start_time,
                              total_success, total_fail,
                              unique_minerals, unnamed_minerals, crystal_system_counts,
                              formula_counts, total_d_spacings, d_spacing_sum,
                              recent_formulas, final=False):
    """Display detailed progress with all requested metrics including rate and success/fail ratio"""
    
    # Calculate basic stats
    elapsed = time.time() - start_time
    speed = processed / elapsed if elapsed > 0 else 0
    remaining = total_files - processed
    eta = remaining / speed if speed > 0 else 0
    
    # Calculate rate per minute
    rate_per_minute = speed * 60
    
    # Calculate metrics
    named_minerals = len(unique_minerals) - len(unnamed_minerals)
    avg_d_spacing = d_spacing_sum / total_d_spacings if total_d_spacings > 0 else 0
    
    # Calculate success/fail stats
    total_processed = total_success + total_fail
    success_percentage = (total_success / total_processed * 100) if total_processed > 0 else 0
    fail_percentage = (total_fail / total_processed * 100) if total_processed > 0 else 0
    
    # Calculate success/fail ratio
    if total_fail > 0:
        success_fail_ratio = total_success / total_fail
        ratio_display = f"{success_fail_ratio:.2f}:1"
    else:
        ratio_display = "∞ (no failures)"
    
    # Find most common crystal systems
    top_crystal_systems = sorted(crystal_system_counts.items(), key=lambda x: x[1], reverse=True)[:3]
    
    # Find most common formulas
    top_formulas = sorted(formula_counts.items(), key=lambda x: x[1], reverse=True)[:3]
    
    # Clear and display
    if not final:
        print("\033[2J\033[H")  # Clear screen and move cursor home
    
    print(f"{'='*100}")
    if final:
        print(f"✅ FINAL STATISTICS")
    else:
        print(f"📊 LIVE PROGRESS UPDATE - {time.strftime('%H:%M:%S')}")
    print(f"{'='*100}")
    
    # Progress bar
    progress_pct = (processed / total_files) * 100
    bar_length = 50
    filled = int(bar_length * processed // total_files)
    bar = "█" * filled + "░" * (bar_length - filled)
    print(f"\n📈 PROGRESS: |{bar}| {progress_pct:6.2f}%")
    print(f"   Processed: {processed:>12,} of {total_files:<12,} | "
          f"Rate: {rate_per_minute:>6.0f}/min | ETA: {eta/60:>6.1f} min")
    
    print(f"\n{'🔍 METRICS':^100}")
    print(f"{'-'*100}")
    
    # 1. Total Mineral Patterns
    print(f"   1️⃣  Total Mineral Patterns:     {processed:>12,}")
    
    # 2. Unique Minerals/Substances
    print(f"   2️⃣  Unique Minerals/Substances:  {len(unique_minerals):>12,}")
    print(f"       ├─ Named:                    {named_minerals:>12,}")
    print(f"       └─ Unnamed:                   {len(unnamed_minerals):>12,}")
    
    # 3. Crystal System Entries
    print(f"\n   3️⃣  Crystal System Distribution:")
    for system, count in top_crystal_systems:
        pct = (count / processed * 100) if processed > 0 else 0
        print(f"       ├─ {system:15}: {count:>8,} ({pct:5.1f}%)")
    if len(crystal_system_counts) > 3:
        print(f"       └─ ... and {len(crystal_system_counts) - 3} more systems")
    
    # 4. Total D-spacing entries
    print(f"\n   4️⃣  Total D-spacing Entries:     {total_d_spacings:>12,}")
    
    # 5. Average D-spacing
    print(f"   5️⃣  Average D-spacing:           {avg_d_spacing:>12.3f} Å")
    
    # 7. Chemical Formula (most common)
    print(f"\n   7️⃣  Most Common Chemical Formulas:")
    for formula, count in top_formulas:
        pct = (count / processed * 100) if processed > 0 else 0
        print(f"       ├─ {formula:15}: {count:>8,} ({pct:5.1f}%)")
    
    # Recent formulas
    if recent_formulas:
        print(f"\n   📝 Recent Formulas: {', '.join(recent_formulas)}")
    
    # Success/Failure stats with ratio
    print(f"\n{'✅ SUCCESS/FAILURE RATIO':^100}")
    print(f"{'-'*100}")
    print(f"   Successful: {total_success:>12,} ({success_percentage:5.1f}%) | "
          f"Failed: {total_fail:>12,} ({fail_percentage:5.1f}%)")
    print(f"   📊 Success:Fail Ratio = {ratio_display}")
    
    if final:
        print(f"\n{'✨ PROCESSING COMPLETE ✨':^100}")
    print(f"{'='*100}\n")

# ================= MAIN =================
def main():
    print(f"{'='*100}")
    print(f"🚀 COD XRD EXTRACTOR - DETAILED METRICS MONITORING WITH RATE AND RATIO")
    print(f"{'='*100}")
    
    # Find all CIF files
    print(f"\n🔍 Scanning for CIF files...", end="", flush=True)
    start_scan = time.time()
    
    cif_files = []
    for root, _, files in os.walk(CIF_ROOT):
        for f in files:
            if f.endswith('.cif'):
                cif_files.append(os.path.join(root, f))
    
    scan_time = time.time() - start_scan
    total_files = len(cif_files)
    
    print(f" found {total_files:,} files in {scan_time:.1f}s")
    
    print(f"\n⚙️  Configuration:")
    print(f"   • Workers: {NUM_PROCESSES}")
    print(f"   • Queue size: {QUEUE_SIZE}")
    print(f"   • Batch size: {BATCH_SIZE}")
    print(f"   • Output: {OUTPUT_DB}")
    
    # Remove existing DB
    if os.path.exists(OUTPUT_DB):
        os.remove(OUTPUT_DB)
        print(f"   • Removed existing database")
    
    # Create process pool
    print(f"\n🚀 Starting {NUM_PROCESSES} worker processes...")
    
    with mp.Manager() as manager:
        queue = mp.Queue(maxsize=QUEUE_SIZE)
        
        # Split files among workers
        chunk_size = len(cif_files) // NUM_PROCESSES
        chunks = []
        for i in range(NUM_PROCESSES):
            start = i * chunk_size
            end = start + chunk_size if i < NUM_PROCESSES - 1 else len(cif_files)
            chunks.append(cif_files[start:end])
        
        # Create and start processes
        workers = []
        for i, chunk in enumerate(chunks):
            w = mp.Process(target=worker_process, args=(chunk, queue, i))
            workers.append(w)
            w.start()
        
        # Start writer
        writer = mp.Process(target=db_writer_process, 
                           args=(queue, total_files, OUTPUT_DB, NUM_PROCESSES))
        writer.start()
        
        # Wait for completion
        for w in workers:
            w.join()
        
        writer.join()
    
    # Final summary
    print(f"\n{'='*100}")
    print(f"✅ PROCESSING COMPLETE")
    print(f"{'='*100}")
    print(f"📁 Database saved to: {OUTPUT_DB}")
    
    if os.path.exists(OUTPUT_DB):
        size_mb = os.path.getsize(OUTPUT_DB) / (1024 * 1024)
        print(f"📊 Database size: {size_mb:.1f} MB")
        
        # Quick database summary
        conn = sqlite3.connect(OUTPUT_DB)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM minerals")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT substance_name) FROM minerals")
        unique_names = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT chemical_formula) FROM minerals")
        unique_formulas = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT crystal_system) FROM minerals WHERE crystal_system != 'UNKNOWN'")
        crystal_systems = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"📈 Final Database Stats:")
        print(f"   • Total entries: {total:,}")
        print(f"   • Unique mineral names: {unique_names:,}")
        print(f"   • Unique formulas: {unique_formulas:,}")
        print(f"   • Crystal systems: {crystal_systems}")

if __name__ == "__main__":
    mp.freeze_support()
    main()